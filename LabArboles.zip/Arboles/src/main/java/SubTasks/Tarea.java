package SubTasks;

import Interfaces.TareaInterna;

public class Tarea implements TareaInterna, Comparable<Tarea>{
	
	private String nombre;
	private boolean completada;
	private ListaDoble<Tarea> dependencias;
	
	public Tarea(String nombre) {
		
		this.nombre = nombre;
		this.completada = false;
		this.dependencias = new ListaDoble<Tarea>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isCompletada() {
		return completada;
	}

	public void setCompletada(boolean completada) {
		this.completada = completada;
	}

	public ListaDoble<Tarea> getDependencias() {
		return dependencias;
	}

	public void setDependencias(ListaDoble<Tarea> dependencias) {
		this.dependencias = dependencias;
	}

	@Override
	public void anadirDependencia(Tarea dependencia) {
		dependencias.insertarAlFinal(dependencia);
	}

	@Override
	public String toString() {
		return "Tarea [nombre=" + nombre + ", completada=" + completada ;
	}

	
	
	@Override
    public void eliminarDependencia(Tarea tareaAEliminar) {
		
    ListaDoble.Nodo<Tarea> actual = dependencias.getCabeza();
    
    ListaDoble.Nodo<Tarea> anterior = null;

    
    
    
    // Buscar la tarea a eliminar en la lista de dependencias
    while (actual != null) {
    	
    	
        if (actual.valor.equals(tareaAEliminar)) {
        	
            // Eliminar la tarea de la lista de dependencias
        	
            if (anterior == null) {
            	
                dependencias.eliminarPrimero(); // La tarea es el primer elemento de la lista
                
            } else {
            	
                anterior.siguiente = actual.siguiente;
            }
            return; // Salir del método una vez eliminada la tarea
        }
        // Avanzar al siguiente nodo
        
        anterior = actual;
        actual = actual.siguiente;
    }
}
	
	
	
    @Override
    public int compareTo(Tarea otraTarea) {
    	
        return this.nombre.compareTo(otraTarea.nombre);
    }
    
}


