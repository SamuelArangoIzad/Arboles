package SubTasks;

import Interfaces.DoblementeEnlazada;

public class ListaDoble <T> implements DoblementeEnlazada<T>{
	
	private Nodo<T> cabeza;
	private Nodo<T> cola;
	private int tamanio;
	
	public ListaDoble() {
		this.cabeza = null;
		this.cola = null;
		this.tamanio = 0;
	}

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public void insertarAlFinal(T valor) {

        Nodo<T> nuevoNodo;
        nuevoNodo = new Nodo<T>(valor);

        if (cabeza == null) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            cola.siguiente = nuevoNodo;
            nuevoNodo.anterior = cola;
            cola = nuevoNodo;
        }

        tamanio++;
    }
    
    @Override
    public void eliminarPrimero() {
        if (cabeza != null) {
            // Si la lista no está vacía
            cabeza = cabeza.siguiente; // Avanzamos la cabeza al siguiente nodo
            if (cabeza != null) {
                cabeza.anterior = null; // Establecemos el anterior de la nueva cabeza como nulo
            } else {
                cola = null; // Si la nueva cabeza es nula, la cola también debe ser nula
            }
        }
    }
    

    public Nodo<T> getCabeza() {
        return cabeza;
    }

    public void limpiar() {
        cabeza = null; // Establecemos la cabeza como nula para eliminar la lista
        cola = null; // Establecemos la cola como nula también
        tamanio = 0; // Reseteamos el tamaño a cero
    }

    public static class Nodo<T> {

        public T valor;
        public Nodo<T> siguiente;
        public Nodo<T> anterior;

        public Nodo(T valor) {

            this.valor = valor;
            this.anterior = null;
            this.siguiente = null;

        }

    }

}