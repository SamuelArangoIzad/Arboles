package Main;

import SubTasks.ListaDoble;
import SubTasks.Tarea;
import TreeFunction.Arbol;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Arbol<Tarea> arbolTareas = new Arbol<Tarea>();

        Scanner scanner = new Scanner(System.in);

        boolean salir = false;

        do {

            System.out.println("---MENÚ---");

            System.out.println("1. Agregar tarea / Agree task");

            System.out.println("2. Agregar dependencias / Agree dependencies");
 
            System.out.println("3. Completar tarea / Complete task");

            System.out.println("4. Ver arbol de tareas y sus dependencias / View tree and dependencies");

            System.out.println("5. Eliminar Nodo / Delete Nodo");

            System.out.println("6. Planificacacion de tareas / Task planning");

            System.out.println("7. Ejecucion de tareas / Task execution");
            
            System.out.println("8. Revision del arbol / Tree inspection");

            System.out.println("9. Salir / Bye :)");

            System.out.print("Escriba una opción: ");

            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {

                case 1:

                    System.out.print("Escriba el nombre de la tarea: ");
                    String nombreTarea = scanner.nextLine();
                    Tarea nuevaTarea = new Tarea(nombreTarea);
                    arbolTareas.añadir(nuevaTarea);

                    break;

                case 2:

                    System.out.print("Escriba el nombre de la tarea para agregar dependencias: ");
                    String nombreTareaDependencias = scanner.nextLine();

                    Arbol.Nodo<Tarea> nodoTarea = buscarTarea(arbolTareas.raiz, nombreTareaDependencias);

                    if (nodoTarea != null) {

                        System.out.print("Escriba el nombre de las dependencias (Escriba 'exit' para salir): ");
                        String nombreDependencia = scanner.nextLine();

                        while (!nombreDependencia.equals("exit")) {

                            Arbol.Nodo<Tarea> nodoDependencia = buscarTarea(arbolTareas.raiz, nombreDependencia);
                            Tarea dependencia;

                            if (nodoDependencia != null) {

                                dependencia = nodoDependencia.valor;
                            } else {

                                dependencia = new Tarea(nombreDependencia);
                                arbolTareas.añadir(dependencia);
                            }
                            nodoTarea.valor.anadirDependencia(dependencia);

                            System.out.print("Escriba el nombre de las dependencias (Escriba 'exit' para salir): ");
                            nombreDependencia = scanner.nextLine();
                        }
                    } else {
                        System.out.println("Tarea no encontrada.");
                    }
                    break;

                case 3:

                    System.out.print("Escriba el nombre de la tarea a completar: ");
                    
                    String nombreTareaCompletar = scanner.nextLine();

                    Arbol.Nodo<Tarea> nodoTareaCompletar = buscarTarea(arbolTareas.raiz, nombreTareaCompletar);
                    
                    if (nodoTareaCompletar != null) {

                        if (nodoTareaCompletar.valor.getDependencias().estaVacia() || todasDependenciasCompletadas(nodoTareaCompletar)) {
                        	
                            arbolTareas.completarTarea(nombreTareaCompletar);
                            
                            System.out.println("Tarea completada");

                        } else {
                        	
                            System.out.println("Todas las dependencias necesitan ser completadas primero.");
                        }
                    } else {
                        System.out.println("Tarea no encontrada.");
                    }

                    break;

                case 4:

                    System.out.println("ÁRBOL DE TAREAS Y DEPENDENCIAS");
                    mostrarArbol(arbolTareas.raiz, "");
                    
                    break;

                case 5:
                	
                	
                    System.out.print("Escriba el nombre de la tarea a eliminar: ");
                    
                    
                    String nombreTareaAEliminar = scanner.nextLine();
                    
                    
                    Arbol.Nodo<Tarea> nodoEliminar = buscarTarea(arbolTareas.raiz, nombreTareaAEliminar);
                    
                    
                    if (nodoEliminar != null) {
                    	
                    	
                        arbolTareas.limpiar(nodoEliminar.valor);
                        
                        
                        eliminarTareaDeDependencias(arbolTareas.raiz, nodoEliminar.valor); // Eliminar de las dependencias de otras tareas
                        
                        
                        System.out.println("Tarea y sus dependencias eliminadas");
                        
                        
                    } else {
                    	
                        System.out.println("¡No encontrada!");
                    }
                    break;

                case 6:

                	//PLANIFICACION HACE VER LOS NODOS DEL ARBOL EN PRE ORDEN
                	//ES DECIR LA EJECUCION DONDE ES EL ORDEN COMO DEBERIA EJECUTARSE LAS TAREAS
                	//EL ORDEN INDICADO PARA COMPLETAR TODO 
                	
                    System.out.println("Planificación de tareas:");
                    arbolTareas.planificarTareas();
                    break;

                case 7:
                	
                	//EN EJECUCION DE TAREAS ES EL POST ORDEN POST DAY XD ES DECIR POSTE ORDEN
                	//LO CONTRARIO AL PRE ORDEN
                	
                	
                    System.out.println("Ejecucion de tareas:");
                    arbolTareas.ejecutarTareas();
                    break;
                case 8:
                	
                	//FINALMENTE REVISION DEL ARBOL ES METODO DE BUSQUEDA AMPLITUD EN SIGSA MI LOCO
                    System.out.println("Revision del arbol:");
                    arbolTareas.revisarTareas();
                    break;
                            
                case 9:

                    salir = true;
                    break;

                default:
                    System.out.println("Opción inválida");
                    break;
            }
        } while (!salir);

        scanner.close();
    }

    
    
    
    private static Arbol.Nodo<Tarea> buscarTarea(Arbol.Nodo<Tarea> nodo, String nombreTarea) {

        if (nodo != null) {

            if (nodo.valor.getNombre().equals(nombreTarea)) {
                return nodo;

            }
            
            Arbol.Nodo<Tarea> izquierda = buscarTarea(nodo.izquierdo, nombreTarea);

            if (izquierda != null) {
            	
                return izquierda;
            }
            
            return buscarTarea(nodo.derecho, nombreTarea);
        }
        return null;
    }

    
    
    private static void eliminarTareaDeDependencias(Arbol.Nodo<Tarea> nodo, Tarea tareaAEliminar) {
    	
        if (nodo != null) {
        	
            // Eliminar la tarea de las dependencias de la tarea actual
        	
            nodo.valor.eliminarDependencia(tareaAEliminar);

            // Llamar recursivamente para las dependencias izquierda y derecha
            
            eliminarTareaDeDependencias(nodo.izquierdo, tareaAEliminar);
            
            eliminarTareaDeDependencias(nodo.derecho, tareaAEliminar);
        }
    }

    
    
    private static void mostrarArbol(Arbol.Nodo<Tarea> nodo, String prefijo) {

        if (nodo != null) {
            System.out.println();
            
            System.out.println(prefijo + nodo.valor);
            
            ListaDoble.Nodo<Tarea> actual = nodo.valor.getDependencias().getCabeza();
            
            while (actual != null) {
            	
                System.out.println(prefijo + " -[Dependencia]- " + actual.valor);
                actual = actual.siguiente;
                
            }
            
            System.out.println("");
            mostrarArbol(nodo.izquierdo, prefijo + "    ");
            mostrarArbol(nodo.derecho, prefijo + "    ");
        }
    }

    
    
    
    private static boolean todasDependenciasCompletadas(Arbol.Nodo<Tarea> nodo) {

        Tarea tarea = nodo.valor;

        if (tarea == null || tarea.getDependencias() == null || tarea.getDependencias().estaVacia()) {
            return true;
        } else {

        	ListaDoble<Tarea> dependencias = tarea.getDependencias();

            ListaDoble.Nodo<Tarea> actual = dependencias.getCabeza();
            
            while (actual != null) {
            	
                if (!actual.valor.isCompletada()) {
                    return false;
                }
                actual = actual.siguiente;
            }
            return true;
        }
    }
}
