package TreeFunction;

import Interfaces.Arbolnterno;
import SubTasks.ListaDoble;
import SubTasks.Tarea;

public class Arbol<T> implements Arbolnterno<T>{
	
     public Nodo<T> raiz;
     
     public Arbol() {
    	 this.raiz=null;
     }
     

     // Metodo para añadir un nuevo valor al arbol
     @Override
     public void añadir(T valor) {

         String nombreTarea = ((Tarea) valor).getNombre();

         // Verificar si ya existe una tarea con el mismo nombre en el árbol
         
         
         if (buscarTarea(raiz, nombreTarea) != null) {
        	 
             System.out.println("Ya existe una tarea con el mismo nombre en el árbol.");
             
             return; // Terminar la inserción para evitar duplicados
         }
         

         Nodo<T> nuevoNodo; // Nuevo nodo para añadir
         
         
         nuevoNodo = new Nodo<T>(valor); // Se crea el nuevo nodo con el valor ingresado
         

         // Si el arbol esta vacio el nuevo nodo se convierte en la raiz
         
         if (raiz == null) {
        	 
             raiz = nuevoNodo;
             
         } else {
        	 
             // Si el arbol tiene raiz se añade el nuevo nodo al primer espacio disponible
        	 
             añadirAlPrimerEspacioDisponible(raiz, nuevoNodo);
         }
     }

     
     
     
     // Metodo que añade el nodo siguiendo el sistema binario
     private void añadirAlPrimerEspacioDisponible(Nodo<T> actual, Nodo<T> nuevoNodo) {
    	 
    	 
         // Si el nodo actual es nulo, entonces el nuevo nodo se convierte en el nodo actual
    	 
         if (actual == null) {
        	 
             actual = nuevoNodo;
             
         } else {
        	 
        	 
             // Comparamos el valor del nuevo nodo con el valor del nodo actual
        	 
             // para determinar si debemos agregarlo a la izquierda o a la derecha
        	 
        	 
             
			Comparable<T> valorNuevo = (Comparable<T>) nuevoNodo.valor;
             
             Comparable<T> valorActual = (Comparable<T>) actual.valor;

             
             if (valorNuevo.compareTo((T) actual.valor) <= 0) {
            	 
                 // Si el valor del nuevo nodo es menor o igual al valor del nodo actual
            	 
                 // lo agregamos al subárbol izquierdo
            	 
                 if (actual.izquierdo == null) {
                	 
                     actual.izquierdo = nuevoNodo;
                     
                 } else {
                	 
                     // Si ya hay un nodo en el sub-arbol izquierdo 
                	 
                     // Se llama recursivamente este metodo para agregar el nuevo nodo en el sub-arbol izquierdo
                     añadirAlPrimerEspacioDisponible(actual.izquierdo, nuevoNodo);
                 }
             } else {
            	 
            	 
                 // Si el valor del nuevo nodo es mayor que el valor del nodo actual
                 // Se agrega en el subarbol derecho
            	 
            	 
            	 
                 if (actual.derecho == null) {
                	 
                     actual.derecho = nuevoNodo;
                     
                 } else {
                	 
                     // Si ya hay un nodo en el subárbol derecho, llamamos recursivamente
                	 
                     // a este método para agregar el nuevo nodo en el subárbol derecho
                	 
                     añadirAlPrimerEspacioDisponible(actual.derecho, nuevoNodo);
                 }
             }
         }
     }

     
     
     private Nodo<T> buscarTarea(Nodo<T> nodo, String nombreTarea) {
    	 
    	 
         if (nodo != null) {
        	 
             Tarea tarea = (Tarea) nodo.valor; // Convertir el valor del nodo a una Tarea
             
             if (tarea.getNombre().equals(nombreTarea)) {
                 return nodo;
             }
             
             Nodo<T> izquierda = buscarTarea(nodo.izquierdo, nombreTarea);
             
             if (izquierda != null) {
                 return izquierda;
             }
             
             return buscarTarea(nodo.derecho, nombreTarea);
         }
         
         return null;
     }

     
     
     // Metodo para planificar las tareas en el arbol en preorden (raiz,arbol izquierda, arbol derecho)
     private void planificaciondelastareas(Nodo<T> nodo, String indentacion) {
    	 
         if (nodo != null) {
        	 
             System.out.println(indentacion + "Planificar tarea: " + nodo.valor);
             // imprime el valor del nodo como tarea a planificar
             
             
             planificaciondelastareas(nodo.izquierdo, indentacion + "  ");
             // Aumentar la indentación para los nodos hijos izquierdos
             
             
             planificaciondelastareas(nodo.derecho, indentacion + "  "); // Aumentar la indentación para los nodos hijos derechos
         }
     }

     
 	//PLANIFICACION HACE VER LOS NODOS DEL ARBOL EN PRE ORDEN
 	//ES DECIR LA EJECUCION DONDE ES EL ORDEN COMO DEBERIA EJECUTARSE LAS TAREAS
 	//EL ORDEN INDICADO PARA COMPLETAR TODO 
 	
     
     public void planificarTareas() {
    	 
         planificaciondelastareas(raiz, ""); // inicia la planificacion desde la raiz con una indentación inicial vacía
     }

     
     // metodo para ejecutar las tareas del arbol
     
 	//EN EJECUCION DE TAREAS ES EL POST ORDEN POST DAY XD ES DECIR POSTE ORDEN
 	//LO CONTRARIO AL PRE ORDEN
     
     public void ejecutarTareas() {
         ejecucionDeTareas(raiz); // inicia la ejecucion desde la raiz
     }

     
     
     // Metodo para ejecutar las tareas recursivamente en post orden (arbol izquierdo, arbol derecho, raiz)
     private void ejecucionDeTareas(Nodo<T> nodo) {
    	 

         if (nodo != null) {
        	 
             // Se ejecutan o completan las tareas de los nodos hijos izquierdo y derecho
             ejecucionDeTareas(nodo.izquierdo);
             
             ejecucionDeTareas(nodo.derecho);
             
             System.out.println("Ejecutar tarea: " + nodo.valor); 
             // se ejecuta la tarea del nodo actual
         }
     }
     

     // metodo para eliminar un valor del arbol
     
     @Override
     public void eliminar(T valor) {
         raiz = eliminarNodo(raiz, valor); // inicia la eliminacion desde la raiz
     }

     
     
     // metodo para eliminar un nodo recursivamente
     
     private Nodo<T> eliminarNodo(Nodo<T> actual, T valor) {
    	 

    	 
         if (actual == null) {
             return null; // si el nodo actual es nulo no se hace nada
         }

         if (actual.valor.equals(valor)) { // Si el valor del nodo actual coincide con el valor a eliminar

             if (actual.izquierdo == null && actual.derecho == null) {
                 return null; // Si el nodo actual es una hoja se elimina volviendolo nulo 
             }

             
             if (actual.izquierdo == null) {
                 return actual.derecho; // Si solo hay hijo derecho se devuelve el hijo derecho
             }
             
             
             if (actual.derecho == null) {
                 return actual.izquierdo; // Si solo hay hijo izquierdo se devuelve el hijo izquierdo
             }
             // Si hay ambos hijos se encuentra el valor minimo del subarbol derecho y se reemplaza el valor del nodo actual
             
             Nodo<T> min = encontrarMinimo(actual.derecho);
             
             actual.valor = min.valor;
             
             actual.derecho = eliminarNodo(actual.derecho, min.valor);
             
             return actual;

         }

         // Se continua la busqueda y eliminación en los nodos hijos izquierdo y derecho
         actual.izquierdo = eliminarNodo(actual.izquierdo, valor);
         
         actual.derecho = eliminarNodo(actual.derecho, valor);
         
         return actual;
     }

     
     
     public void limpiar(Tarea tarea) {
    	 
         if (tarea != null) {
        	 
             // Eliminar dependencias recursivamente
        	 
             ListaDoble.Nodo<Tarea> actual = tarea.getDependencias().getCabeza();
             
             while (actual != null) {
            	 
                 limpiar(actual.valor); // Llama recursivamente para eliminar las dependencias y tareas relacionadas
                 
                 actual = actual.siguiente;
                 
             }
             // Una vez eliminadas las dependencias y tareas relacionadas, elimina la tarea principal
             
             eliminarNodo(raiz, (T) tarea);
         }
     }

     
     
     // metodo para encontrar el nodo con el valor minimo en un subarbol
     private Nodo<T> encontrarMinimo(Nodo<T> actual) {
    	 

         while (actual.izquierdo != null) {
        	 
             actual = actual.izquierdo; // Se avanza hacia la izquierda hasta encontrar el valor minimo
         }
         
         return actual; // Se devuelve el nodo con el valor minimo
     }

     
     
     // metodo para buscar un valor por amplitud en el arbol
     
     @Override
     
   //FINALMENTE REVISION DEL ARBOL ES METODO DE BUSQUEDA AMPLITUD EN SIGSA MI LOCO
     public void revisarTareas() {
    	 
     if (raiz == null) {
    	 
         System.out.println("El árbol está vacío.");
         
         return;
     }

     
     Cola<Nodo<T>> cola = new Cola<>(); // Suponiendo que Cola está definida correctamente
     

     // Agregar el nodo raíz a la cola
     
     cola.enqueue(raiz); // Utiliza el método de tu Cola para encolar un elemento

     while (!cola.estaVacia()) {
    	 
         Nodo<T> nodoActual = cola.dequeue(); // Desencolar el nodo de la cola
         

         // Procesar el nodo actual, por ejemplo, revisar su progreso o realizar alguna otra operación
         
         System.out.println("Revisar tarea: " + nodoActual.valor);

         
         // Agregar los hijos del nodo actual a la cola para ser revisados en la siguiente iteración
         if (nodoActual.izquierdo != null) {
        	 
             cola.enqueue(nodoActual.izquierdo);
         }
         
         if (nodoActual.derecho != null) {
             cola.enqueue(nodoActual.derecho);
         }
         
     }
     
 }

     // metodo para completar una tarea especifica en el arbol
     
     public void completarTarea(String nombre) {
    	 
         completarTarea(raiz, nombre); // inica la busqueda y completa desde la raiz
         
     }

     // metodo para completar una tarea especifica recursivamente
     
     private void completarTarea(Nodo<T> nodo, String nombre) {
    	 
         if (nodo == null) {
        	 
             return; // si el nodo actual es nulo no se hace nada
         }

         T valor = nodo.valor; // valor del nodo actual

         // si el valor del nodo es una tarea y coincide con el nombre dado se marca como completada
         
         if (valor != null && valor.getClass().equals(Tarea.class)) {
        	 
             Tarea tarea = (Tarea) valor; // se convierte el valor a tipo Tarea
             
             if (tarea.getNombre().equals(nombre)) {
            	 
                 tarea.setCompletada(true); // se marca la tarea como completada
             }
         }

         // se continua la busqueda y completacion en los nodos hijos izquierdo y derecho
         
         completarTarea(nodo.izquierdo, nombre);
         
         completarTarea(nodo.derecho, nombre);
     }



     public static class Nodo<T> {

         public T valor;
         public Nodo<T> izquierdo;
         public Nodo<T> derecho;


         public Nodo(T valor) {

             this.valor = valor;
             this.izquierdo = null;
             this.derecho = null;
         }
     }


}
