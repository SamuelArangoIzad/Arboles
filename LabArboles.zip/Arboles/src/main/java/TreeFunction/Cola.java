package TreeFunction;

public class Cola<T> {
	
    private NodoCola<T> frente, fin;
 
    
    public Cola(){
        frente = fin = null; 
    }
    
    public void enqueue(T valor){
    	
        NodoCola<T> nuevoNodo;
        
        nuevoNodo = new NodoCola<T>(valor); // crea un nuevo nodo con el valor dado
        
        if (fin == null){
        	
            frente = fin = nuevoNodo; // si la cola está vacia el nuevo nodo se convierte en frente y fin
        
        } else {
        	
            fin.siguiente = nuevoNodo; // el siguiente del ultimo nodo apunta al nuevo nodo
            fin = nuevoNodo; // el nuevo nodo se convierte en el ultimo nodo
            
        }
        
    }
    
    public T dequeue() {
    	
        if (frente == null) {
        	
            return null; // si la cola esta vacia devuelve nulo
            
        }
        
        T valor = frente.valor; // almacena el valor del frente de la cola
        frente = frente.siguiente; // el frente de la cola se mueve al siguiente nodo
        
        if (frente == null) {
        	
            fin = null; // si el frente es nulo el fin tambien se vuelve nulo
            
        }
        
        return valor; // devuelve el valor del nodo eliminado
    }
 
    
    public boolean estaVacia(){
    	
        return frente == null; 
        
    }
    
    
    public static class NodoCola<T>{
    	
        T valor;
        NodoCola<T> siguiente;
 
        public NodoCola(T valor){
        	
            this.valor = valor; 
            this.siguiente = null; 
            
        }
        
    }
    
}