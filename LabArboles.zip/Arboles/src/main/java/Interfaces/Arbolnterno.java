package Interfaces;

//ARbol INterno

public interface Arbolnterno <T>{

	void añadir(T valor);
	void eliminar(T valor);
	void planificarTareas();
	void ejecutarTareas();
	void revisarTareas();
	
}
