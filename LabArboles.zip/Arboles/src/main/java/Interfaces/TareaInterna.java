package Interfaces;

//TaSK

import SubTasks.Tarea;

public interface TareaInterna {

	void anadirDependencia(Tarea dependencia);
	void eliminarDependencia(Tarea tareaAEliminar);
	
}
