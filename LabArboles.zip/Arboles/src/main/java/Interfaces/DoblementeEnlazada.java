package Interfaces;

//Lista DoBlemente enlazada

public interface DoblementeEnlazada <T>{

	boolean estaVacia();
	void insertarAlFinal(T valor);
	void eliminarPrimero();
	
	
}
