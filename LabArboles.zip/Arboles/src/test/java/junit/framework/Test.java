package junit.framework;

public class Test {

	//Aca no hay nada 
}
